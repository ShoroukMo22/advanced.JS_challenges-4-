const INITIAL = 100;

function add(a, b) {
  return a + b;
}

function subtract(a, b) {
  return a - b;
}

function devide(a, b) {
  return a / b;
}

function multiply(a, b) {
  return a * b;
}

export {
  add,
  subtract,
  devide,
  multiply,
};

export default INITIAL;
